import { useEffect } from 'react';
import EmployeeLayout from '../components/EmployeeLayout';
import { useStore } from '../store/useStore';

export default function MyTablesPage() {
  const tables = useStore((state) => state.tables);
  const loading = useStore((state) => state.tablesLoading);
  const error = useStore((state) => state.tablesError);
  const fetchTables = useStore((state) => state.fetchTables);
  const employee = useStore((state) => state.employee);

  useEffect(() => {
    fetchTables(false);
  }, [fetchTables]);

  const employeeId = employee?.id || employee?._id;

  // Filter tables assigned to the logged-in waiter
  const assignedTables = tables.filter((table) => {
    const assignedId = table.assignedWaiter?.id || table.assignedWaiter?._id || table.assignedWaiter;
    return assignedId && employeeId && assignedId.toString() === employeeId.toString();
  });

  return (
    <EmployeeLayout>
      <div className="flex flex-col gap-6 animate-fade-in max-w-lg mx-auto">
        {/* Page Header */}
        <div>
          <h1 className="text-2xl font-black text-slate-900">My Tables</h1>
          <p className="text-xs text-slate-500 mt-0.5">Tables assigned to you for service</p>
        </div>

        {/* Error State */}
        {error && (
          <div className="flex items-center gap-2 rounded-xl px-4 py-3 text-xs font-semibold bg-red-50 border border-red-200 text-red-700">
            <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <span>{error}</span>
          </div>
        )}

        {/* Loading Spinner / Skeletons */}
        {loading ? (
          <div className="grid grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="glass rounded-3xl p-5 border border-slate-200 bg-white flex flex-col gap-2 shadow-sm">
                <div className="skeleton h-6 w-1/2" />
                <div className="skeleton h-4 w-3/4" />
              </div>
            ))}
          </div>
        ) : assignedTables.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-4 py-16 text-center bg-white border border-slate-200 rounded-3xl shadow-sm p-6">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center bg-slate-100 border border-slate-200 text-3xl">
              🪑
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">No Assigned Tables</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-[260px] leading-relaxed">
                You haven't been assigned to any tables. Please contact your restaurant manager or owner.
              </p>
            </div>
          </div>
        ) : (
          /* Grid list of tables */
          <div className="grid grid-cols-2 gap-4">
            {assignedTables.map((table) => (
              <div
                key={table.id}
                className="glass rounded-3xl p-5 border border-slate-200 bg-white shadow-sm flex flex-col gap-2 transition-all hover:scale-[1.01]"
              >
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Table Code: {table.code}</span>
                <h3 className="text-lg font-black text-slate-900">{table.name}</h3>
                {/* {table.description && (
                  <p className="text-xs text-slate-600 leading-relaxed">{table.description}</p>
                )} */}
                <div className="mt-2 flex items-center gap-1.5 text-[11px] font-bold text-green-700 bg-green-50 border border-green-200 rounded-lg px-2.5 py-1 self-start">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                   {table.description && (
                  <p className="text-xs text-slate-600 leading-relaxed">{table.description}</p>
                )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </EmployeeLayout>
  );
}
